function login(){
    var login = "";
    var senha = "";

    login = document.getElementById("login").value;
    senha = document.getElementById("id").value;

    if(baseFake(login,senha)){
        document.getElementById("message").innerHTML = "Deu Certo!"
    }else{
        document.getElementById("message").innerHTML = "Deu Errado!"
    }

}
// Checklist de usuários com login
function baseFake(login, senha) {
    const lista = [
        {login: "teste", senha: "123"},
        {login: "usuario", senha: "456"},
        {login: "jao", senha: "789"},
    ]

    for(var i=0;i<lista.length;i++) {
        var verify = lista[i];
        if(verify.login == login && verify.senha == senha){
            return true;
        }
    }
    return false;
}
// Função para o Click
document.getElementById("botao").addEventListener(
    'click',
    function(){
        login();
    }
)