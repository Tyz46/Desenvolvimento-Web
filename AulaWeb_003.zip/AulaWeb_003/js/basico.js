// Variáveis

var teste = 2; // declara uma variável
let teste1 = 1; // declara uma variável em escopo de bloco
const teste2 = 2; // declara uma constante em escopo de bloco

console.log(teste);

// Array

const MY_ARRAY = ["HTML", "CSS"]; // Declarando um Array
MY_ARRAY.push("JS"); // Adicionando algo a um Array
console.log(MY_ARRAY);

// Controle de Fluxo
//// Condicionais
if (teste == teste1) {
    console.log("A soma desta conta da 3!");
} else {
    console.log("Sei la!");
};

if (teste == 1) {
    console.log("X é igual a 3!");
} else if (teste == 2) {
    console.log("X é igual a 2!");
} else {
    console.log("Sei la!");
};

//// Laços
// Funções

function myFunc(theObj) {
    theObj.make = "Toyota";
}

const myCar ={
    make: "Honda",
    model: "Accord",
    year: "1998",
};

console.log(myCar.make);
myFunc(myCar);
console.log(myCar.make);